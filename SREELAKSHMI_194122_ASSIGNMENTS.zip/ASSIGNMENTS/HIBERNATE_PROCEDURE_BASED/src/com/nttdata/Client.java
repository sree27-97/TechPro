package com.nttdata;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String[] args) {
		Configuration configure=new Configuration();
		configure.configure("HibernateConfig.xml");
		SessionFactory sessionFactory=configure.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Query query = session.createSQLQuery("call selectdetails()").addEntity(Student.class);
		List<Student> list=query.list();
		for(Student s:list)
		{
			System.out.println(s);
		}
				

	}

}
