package com.nttdata.customException;

import java.util.Scanner;

public class Bank {
	Account account1=null,account2=null;
	Scanner scanner=new Scanner(System.in);
	User user;

	
	void FundTranfer(User u1,User u2,double amount) throws Insufficientamount
	{
		if(u1.getAccount().getAmount()<amount)
		{
			throw new Insufficientamount("you have no ammount");
		}
		else
		{
			double u1amt=	u1.getAccount().getAmount();
			u1.getAccount().setAmount(u1amt-amount);
			double u2amt= u2.getAccount().getAmount();
			u2.getAccount().setAmount(amount+u2amt);
		}
	}
	 User createFirstAccount(){
		 System.out.println("Enter Account Holder Name");
			String accName1=scanner.next();
			System.out.println("Enter Account Id");
			int accountId1=scanner.nextInt();
			System.out.println("Enter depositing Amount");
			double amount1=scanner.nextDouble();
			account1=new Account(accountId1,amount1);
			user=new User(accName1,account1);
			return user;
	 }
}
