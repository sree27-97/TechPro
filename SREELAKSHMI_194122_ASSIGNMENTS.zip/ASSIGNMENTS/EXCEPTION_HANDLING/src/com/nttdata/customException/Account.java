package com.nttdata.customException;

public class Account {
	
	private int accId;
	private double accamount;
	
	public Account(int accId, double amount) {
		super();
		this.accId = accId;
		this.accamount = amount;
	}
	
	public int getAccountId() {
		return accId;
	}
	public void setaccId(int accId) {
		this.accId = accId;
	}
	public double getAmount() {
		return accamount;
	}
	public void setAmount(double accamount) {
		this.accamount = accamount;
	}
	

}
