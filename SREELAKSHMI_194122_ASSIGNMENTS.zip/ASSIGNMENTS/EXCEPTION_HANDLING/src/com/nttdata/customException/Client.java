package com.nttdata.customException;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws Insufficientamount  {
		Bank bank1= new Bank();
		User user1=null ,user2=null;
		Scanner scanner=new Scanner(System.in);
		int choice = 0;
		
		
		System.out.println("Welcome to Bank Application.....!!!!!!!");
		System.out.println("1. Create Account\t2.Transfer Amount\t3.Quit");
		choice=scanner.nextInt();
		do{
			
			
			switch(choice)
			{
			case 1: System.out.println("-------------Create Minimum Two Accounts--------------");
					System.out.println("1.To Create Account\t2. To create another account\t3. Quit");
					int choice1=scanner.nextInt();
					switch(choice1)
					{
					case 1: System.out.println("---------------Creating your Account---------------\n");
					 		user1=bank1.createFirstAccount();
					 		System.out.println("Initial Account Created Successfully\n");
							break;
							
					case 2: System.out.println("---------------Creating Another account your Account-----------------\n");
							user2=bank1.createFirstAccount();
							System.out.println(" 2nd Account Created Successfully\n");
							break;
					case 3:System.out.println("Thank you");
							break;				
					}
					break;
				
			case 2 : if(user1==null){
					System.out.println("--------Please go back and create an account for fund tranfer------------");
					break;
					}
				else if(user2==null){
					System.out.println("------Create an another account for fund tranfer--------");
					user2=bank1.createFirstAccount();
				}
					System.out.println("-------To Trasfer Fund-------");
				
					System.out.println("User1 : "+user1.getUsername()+"  Account Id: "+ user1.getAccount().getAccountId()+"  Amount :"+user1.getAccount().getAmount());
					System.out.println("User1 : "+user2.getUsername()+"  Account Id: "+ user2.getAccount().getAccountId()+"  Amount :"+user2.getAccount().getAmount());
					System.out.println("\nPress 1. Trasfer from User 1 to User 2\t 2. Trasfer from User 2 to User 1\t3. Quit");
					int ch=scanner.nextInt();
					try{
					switch(ch)
					{
					case 1 : 
							 System.out.println("Enter the amount need to be transfer");
							 double fund1=scanner.nextDouble();
							 bank1.FundTranfer(user1, user2, fund1);
							 System.out.println("----Amount transffered Successfully----");
							 System.out.println("Current Balance is:");
							 System.out.println("User1 : "+user1.getUsername()+"  Account Id: "+ user1.getAccount().getAccountId()+"  Amount :"+user1.getAccount().getAmount());
							 System.out.println("User1 : "+user2.getUsername()+"  Account Id: "+ user2.getAccount().getAccountId()+"  Amount :"+user2.getAccount().getAmount());
							 break;
					
					case 2 : Bank bank2= new Bank();
					 		 System.out.println("Enter the amout need to be trasfer");
					 		 double fund2=scanner.nextDouble();
					 		 bank2.FundTranfer(user2, user1, fund2);
					 		 System.out.println("----Amount transffered Successfully----");
					 		 System.out.println("Current Balance is:");
					 		 System.out.println("User1 : "+user1.getUsername()+"  Account Id: "+ user1.getAccount().getAccountId()+"  Amount :"+user1.getAccount().getAmount());
					 		 System.out.println("User1 : "+user2.getUsername()+"  Account Id: "+ user2.getAccount().getAccountId()+"  Amount :"+user2.getAccount().getAmount());
					 		 break;
							 
					}
					}catch(Insufficientamount e)
					{
						e.printStackTrace();
					}
			
			}
		
			
			System.out.println("\nWelcome to Bank Application.....!!!!!!!");
			System.out.println("1. Create Account\t2.Transfer Amount\t3.Quit");
			choice=scanner.nextInt();
		}while(choice!=0);
		
		scanner.close();

	}

}
