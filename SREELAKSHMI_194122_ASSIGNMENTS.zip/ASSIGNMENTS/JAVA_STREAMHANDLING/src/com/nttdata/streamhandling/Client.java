package com.nttdata.streamhandling;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Client {

	public static void main(String[] args) {
		
		List<Employee> employeeList=new ArrayList<Employee>();
		
		employeeList.add(new Employee(194,"Nagashree",25000,22));
		employeeList.add(new Employee(852,"Manisha",28000,23));
		employeeList.add(new Employee(567,"Samyukta",30000,23));
		employeeList.add(new Employee(965,"Sunil",9000,28));
		employeeList.add(new Employee(254,"Vrinda",36542,23));
		employeeList.add(new Employee(365,"Charan",10000,20));
		
		System.out.println("---------------JAVA 8 FEATURES---------------\n");
		
		//List employeeSalaryList=(List) employeeList.stream().filter(p->p.getEmployeeSalary()>10000).collect(Collectors.toList());
		List employeeSalaryList=(List) employeeList.stream().filter(p->p.getEmployeeSalary()>10000).map(p->p.getEmployeeName()).collect(Collectors.toList());
		System.out.println("Name of Employees whose Salary is more than 10000\n");
		System.out.println(employeeSalaryList);
		
		long count=employeeList.stream().filter(p->p.getEmployeeSalary()>10000).collect(Collectors.counting());
		System.out.print("\nNumber of employees whose Salry id more than 10000 : "+count);
		
	}

}
