package com.nttdata.OnetoMany;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class Client {
	public static void main(String[] args) {
		Configuration config=new Configuration();
		config.configure("HibernateConfig.xml");
			
		SessionFactory sessionFactory=config.buildSessionFactory();
		Session session=sessionFactory.openSession();
	
	int ch;
	Scanner scanner =new Scanner(System.in);
	int ter;
	do{
		
	
	System.out.println("--------------One-to-Many using Hibernate---------------\n");
	System.out.println("1. INSERT\t2. FETCH\t3.DELETE");
	ch=scanner.nextInt();
	
	switch(ch)
	{
	case 1: System.out.println("Enter the Details of Category");
			System.out.print("Enter CategoryID : ");
			int categoryID=scanner.nextInt();
			System.out.print("Enter CategoryName : ");
			String categoryName=scanner.next();
			Category category=new Category();
			category.setCategoryId(categoryID);
			category.setCategoryName(categoryName);
			System.out.println("Enter Number of Products wants to Insert");
			int num=scanner.nextInt();
			Product[] product=new Product[num];
			List cate=new ArrayList();
			
			for (int i=0;i<num;i++)
			{
				product[i]=new Product();
				System.out.println(i+" Enter PtoductID");
				int productID=scanner.nextInt();
				System.out.println(i+" ProductName");
				String productName=scanner.next();
				product[i].setProductId(productID);
				product[i].setProductName(productName);
				cate.add(product[i]);
			}
			category.setCategory(cate);
			Transaction transaction=session.beginTransaction();
			session.save(category);
			transaction.commit();
			
			
			break;
			
	case 2 :Transaction transaction1=session.beginTransaction();
	
			String sql="FROM Category";
			Query query=session.createQuery(sql);
			 List<Category> list=query.list();    
			 Iterator it=list.iterator();
			 while(it.hasNext())
			 {
				 Category c=(Category) it.next();
				 System.out.println("Category id "+c.getCategoryId());
				 System.out.println("Category name "+c.getCategoryName());
				 int id=c.getCategoryId();
				 //System.out.println(id);
				 
				 Query query1 = session.createQuery("FROM Product P WHERE P.foreignid ="+id);
				 List<Product> list1=query1.list();
					Iterator itr=list1.iterator();
					while(itr.hasNext())
					{
						Object o=itr.next();
						Product p=(Product)o;
						System.out.println("\nProduct  details : "+p.getProductId()+"\t"+p.getProductName());
				
					}
				 
			}
	
			transaction1.commit();
			break;
	
	case 3 :Category catdel=new Category();
			System.out.println("Enter the  CategoryId to be deleted");
			int catId=scanner.nextInt();
			catdel.setCategoryId(catId);
			Object ob=session.load(Category.class, new Integer(catId));
			Category cat1=(Category)ob;
			session.delete(cat1);
			Transaction transaction2=session.beginTransaction();
			
			transaction2.commit();
			
			System.out.println("DELETED");
			break;
			
	case 4: System.exit(0);
	
	}
	
	
	}while(ch!=4);
	session.close();
	System.out.println("Thank You");
	}
}
