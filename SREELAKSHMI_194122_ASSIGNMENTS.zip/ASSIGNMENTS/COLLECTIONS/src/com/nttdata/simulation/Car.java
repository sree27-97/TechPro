package com.nttdata.simulation;

public class Car extends Vehicle{
	
	private String carNo;
	private String carName;
	private double carPrice;
	private String carColor;
	private int maximumSpeed;


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}


	public String getcarNo() {
		return carNo;
	}


	public void setCarNumber(String carNo) {
		this.carNo = carNo;
	}


	public String getCarName() {
		return carName;
	}


	public void setCarName(String carName) {
		this.carName = carName;
	}


	public double getCarPrice() {
		return carPrice;
	}


	public void setCarPrice(double carPrice) {
		this.carPrice = carPrice;
	}



	public String getCarColor() {
		return carColor;
	}


	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}



	public int getMaximumSpeed() {
		return maximumSpeed;
	}


	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}


	public Car(String carNo, String carName, double carPrice, String carColor, int maximumSpeed) {
		super();
		this.carNo = carNo;
		this.carName = carName;
		this.carPrice = carPrice;
		this.carColor = carColor;
		this.maximumSpeed = maximumSpeed;
	}

	void display() {
		System.out.println("Car Number: "+carNo+"\nCar Name: "+carName+"\nCar Price: "+carPrice+"\nCar Color: "+carColor+"\nMaximum Speed :"+maximumSpeed);
		
	}
	
	

}
