package com.nttdata.simulation;

public class Engine {
	Engine start(){
		System.out.println("Engine Started");
		return null;
	}
	
	Engine stop(){
		System.out.println("Engine Stopped");
		return null;
		
	}
}
