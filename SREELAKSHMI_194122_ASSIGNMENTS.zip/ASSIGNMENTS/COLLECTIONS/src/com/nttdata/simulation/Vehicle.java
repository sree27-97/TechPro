package com.nttdata.simulation;

public abstract  class Vehicle extends Engine {
	//has a relationship with engine
	 Engine engine;
	 abstract void display();
	 
}
