package com.nttdata.simulation;

public class Bus extends Vehicle {
	private String busNo;
	private String busName;
	private double busPrice;
	private String busColor;
	private int maximumSpeed;
	Engine engine;
	
	
	public Bus(String busNumber, String busName, double busPrice, String busColor, int maximumSpeed) {
		super();
		this.busNo = busNumber;
		this.busName = busName;
		this.busPrice = busPrice;
		this.busColor = busColor;
		this.maximumSpeed = maximumSpeed;
	}


	public String getBusNumber() {
		return busNo;
	}


	public void setBusNumber(String busNo) {
		this.busNo = busNo;
	}


	public String getBusName() {
		return busName;
	}


	public void setBusName(String busName) {
		this.busName = busName;
	}


	public double getBusPrice() {
		return busPrice;
	}


	public void setBusPrice(double busPrice) {
		this.busPrice = busPrice;
	}


	public String getBusColor() {
		return busColor;
	}


	public void setBusColor(String busColor) {
		this.busColor = busColor;
	}


	public int getMaximumSpeed() {
		return maximumSpeed;
	}


	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}


	public Engine getEngine() {
		return engine;
	}


	public void setEngine(Engine engine) {
		this.engine = engine;
	}


	void display() {
		System.out.println("bus Number: "+busNo+"\nbus Name: "+busName+"\nbus Price: "+busPrice+"\nbus Color: "+busColor+"\nMaximum Speed :"+maximumSpeed);
		
	}
	
}
