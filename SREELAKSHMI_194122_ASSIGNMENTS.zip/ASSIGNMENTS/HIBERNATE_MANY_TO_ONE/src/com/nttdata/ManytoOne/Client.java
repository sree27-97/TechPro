package com.nttdata.ManytoOne;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;






public class Client {

	public static void main(String[] args) {
		Configuration configure=new Configuration();
		configure.configure("HibernateConfig.xml");
		SessionFactory sessionFactory=configure.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		int ch;
		Scanner scanner =new Scanner(System.in);
		int ter;
		do{
			
		System.out.println("--------------Many-to-One using Hibernate---------------\n");
		System.out.println("1. INSERT\t2. FETCH\t3. DELETE\t4. EXIT");
		ch=scanner.nextInt();
		switch(ch)
		{
		case 1: System.out.println("Enter the Details of Category");
				System.out.print("Enter CategoryID : ");
				int categoryID=scanner.nextInt();
				System.out.print("Enter CategoryName : ");
				String categoryName=scanner.next();
				Category category=new Category();
				category.setCategoryId(categoryID);
				category.setCategoryName(categoryName);
				System.out.println("Enter Number of Products wants to Insert");
				int num=scanner.nextInt();
				Product[] product=new Product[num];
				for (int i=1;i<=num;i++)
				{
					product[i]=new Product();
					System.out.println(i+" Enter PtoductID");
					int productID=scanner.nextInt();
					System.out.println(i+" ProductName");
					String productName=scanner.next();
					product[i].setProductId(productID);
					product[i].setProductName(productName);
					product[i].setCategory(category);
					session.save(product[i]);
					
				}
				
				Transaction transaction=session.beginTransaction();
				
				transaction.commit();
				
				System.out.println(num+" products inserted successfully");
				break;
				
		case 2: 
				Transaction transaction1=session.beginTransaction();
		
				String sql="FROM Product";
				Query query=session.createQuery(sql);
				List<Product> list=query.list();
				Iterator it=list.iterator();
				while(it.hasNext())
				{
					Object o=it.next();
					Product p=(Product)o;
				
					System.out.println("\nProduct  details : "+p.getProductId()+"\t"+p.getProductName()+"\t"+p.getCategory());
			
				}
				transaction1.commit();
				
				
				break;
		
		case 3:	System.out.println("Enter the  ProductId to be deleted");
				int prodId=scanner.nextInt();
				String hql = "DELETE FROM Product "  + 
		             "WHERE productId = :product_id";
				Query query1 = session.createQuery(hql);
				query1.setParameter("product_id", prodId);
				int result = query1.executeUpdate();
				System.out.println("Rows deleted: " + result);
			break;
			
		case 4: System.exit(0);
		}
		
		
		
		}while(ch!=4);
		
		
		session.close();
		System.out.println("THANK YOU");
		
		
	}

}
